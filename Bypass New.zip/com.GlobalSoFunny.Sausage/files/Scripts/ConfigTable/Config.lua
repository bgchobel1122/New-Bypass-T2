--[[
	配置文件
	查看详细：/server/bin/config/*.json
--]]

var("DevelopPushKafakaConfigConfig", "FirstPushKafakaConfigConfig", "FirstSensitiveWordConfig", "FirstV2WhisperConfigConfig", "GlobalShopConfig", "GlobalV2WhisperConfigConfig", "ReleasePushKafakaConfigConfig", "ReleaseShopConfig", "SensitiveWordConfig", "V2WhisperConfigConfig", "AchievementCacheConfig", "ActivityMapConfig", "ActivityTypeConfig", "AilevelConfig", "AntiAddictionConfig", "AntiCheatConfig", "AntiCheatInfoConfig", "ChatConfig", "ChatGsConfig", "ClientConfig", "ClientTypeConfig", "ClubConfig", "ConfigOfClientTypeCheckConfig", "CrateConfig", "DataInfoConfigConfig", "DifficultyOfGameConfig", "DifficultyScoreConfig", "EquipStateConfig", "ErrClientMatchConfig", "FpsPickerConfig", "FreezeReportTypeRedisKeyConfig", "FriendConfig", "FriendPKConfigConfig", "GameServerTypeConfig", "GroupConfig", "GroupmodConfig", "ItemConfig", "ItemStateConfig", "MailConfig", "MatchOfCoefficientConfig", "OperatingSystemConfig", "PlayerConfig", "PlayerIdentityConfig", "PlayerRoomStateConfig", "PlayerStateConfig", "RankingConfig", "RecallActivityConfig", "ReportConfig", "RoomConfig", "ServerTypeConfig", "TaskConfig", "TrafficPermitConfig", "UnetConfig", "VipConfig", "WarConfig", "WarStateConfig")

DevelopPushKafakaConfigConfig = {
	KafkaTopics = "develop_push_friend",
	KafkaServers = "47.102.121.47:9093,47.102.144.92:9093,47.102.159.177:9093",
	KafkaChannelSize = 256,
	KafkaConsumerCount = 1,
	KafkaAK = "",
	KafkaPassword = "",
	KafkaCertFile = "",
	KafkaCertBytes = "",
	KafkaConsumerId = "CID_DEVELOP_PUSH_FRIEND",
	TryConsumTimes = 3,
	TryConsumSleepTime = 1000,
}

FirstPushKafakaConfigConfig = {
	KafkaTopics = "relation_push_xcpd_first",
	KafkaServers = "192.168.0.78:9092,192.168.0.81:9092,192.168.0.79:9092",
	KafkaChannelSize = 256,
	KafkaConsumerCount = 1,
	KafkaAK = "",
	KafkaPassword = "",
	KafkaCertFile = "",
	KafkaCertBytes = "",
	KafkaConsumerId = "CID_FIRST_PUSH_FRIEND",
	TryConsumTimes = 3,
	TryConsumSleepTime = 1000,
}

FirstSensitiveWordConfig = {
	XdTextCheckApiEnable = true,
	XdTextCheckApiTest = false,
	XdTextCheckApiUrl = "https://api-megats.xdapp.com/v1/text/check",
	XdTextCheckApiToken = "Bearer eyJhbGciOiJSUzI1NiIsImtpZCI6ImJjZGZkZTBmLTI3YTQtNDExZS05MjJhLTY0MjI4NWZmNGJmMyJ9.eyJpc3MiOiJodHRwczovL3d3dy54ZGFwcC5jb20iLCJhdWQiOiJtZWdhLnRleHRzYXZlciIsImFwcCI6InNhdXNhZ2VfZmlyc3QifQ.bVj7fCUhrMyZQM9-iUjW4NN8Xe0wzfuMMew_il9Q9LCqk9-ZIeqOUrcMb-3qrNKnmXTPXg74p0EQmuny7BjaUjmSNP8JAcao8-NNfJYcG3IwC6r79j5MlhyrC9Y8FBYKfu4IZexgfGWNeOqswqPbLd5o94hXeatQBTpO3WNY0YuQhhgUTaJsRep2foqYq_6nNLo8LMRQqYkPAvc8KplXhydkktq8Y04T9q_RMrs0YdaZ89WxsNTBtTIoX4aJq5jQiutCjuAE3WcpfPaHCbF8J2UPdHocyqM50OR_Jgl5FVeJsQlOyl1hJo3z8Rrvxzx1H_pMyfi1gOmfHWM9F36G5A",
	XdTextCheckApiApp = "sausage_first",
	XdTextCheckApiInterval = 86400,
	XdTextCheckApiCheckVer = 4,
	MailXdTextCheckApiEnable = true,
	ChatXdTextCheckApiEnable = true,
	ChatCheckEnable = true,
}

FirstV2WhisperConfigConfig = {
	XdTextCheckApiEnable = true,
	XdTextCheckApiUrl = "https://whisper.cn.tapapis.com/v2/text/check",
	XClientID = "fYVlqCuJfc36ULkn0s",
	XServerSecret = "8Nq84oQ6ckvjWGQCBfWlwtJCDB9t1CwF",
	XSceneChat = "c2hi2eg4kfrmdolmvr4g",
	XSceneNickname = "c2hi2emg2oast3veekog",
	MailXdTextCheckApiEnable = true,
	ChatXdTextCheckApiEnable = true,
	ChatCheckEnable = true,
}

GlobalShopConfig = {
	PayValidDelayTime = 3600,
	OrderMaxValidTime = 300,
	DailySelectShopPeriod = 86400,
	LaoShouLoginDayMin = 11,
	XiaoRPayMin = 1,
	ZhongRPayMin = 4.99,
	DaRPayMin = 29.99,
	MaxPushTimes = 3,
	AgeRecordTime = 2592000,
	GiftFocusTimeLimit = 259200,
	GiftDailySendLimit = 7,
	GiftScoreLimit = 1500,
	GiftLockAgeTime = 300,
	GiftBeforeEndTime = 3600,
	CouponShopDiscount = {
		[1] = 10,
		[2] = 40,
		[234881024] = 0,
		[3] = 150,
		[4] = 400,
		[5] = 1200,
		[6] = 0,
	},
	SurpriseShopCdDayMin = 1,
	SurpriseShopCdDayMax = 1,
	SurpriseShopForbidDay = 5,
	SurpriseShopBuyDay = 3,
	SurpriseShopAdvanceCount = 2,
	SurpriseShopAdvanceAge = 4,
	DailySelectShopXiaoRDiamond = 60,
	DailySelectShopZhongRDiamond = 300,
	DailySelectShopDaRDiamond = 600,
	DirectPurchaseTopicOpenDays = 90,
	GiftRelationItemNumSingleLimit = 100,
}

GlobalV2WhisperConfigConfig = {
	XdTextCheckApiEnable = true,
	XdTextCheckApiUrl = "https://whisper-sg.intl.tapapis.com/v2/text/check",
	XClientID = "sausage-sg",
	XServerSecret = "Pd7BLHR6flXNDlp92TY0ltlFKKU4DOPO",
	XSceneChat = "c2hicergg3hfgbbq3uf0",
	XSceneNickname = "c2hicergg3hfgbbq3ufg",
	MailXdTextCheckApiEnable = true,
	ChatXdTextCheckApiEnable = true,
	ChatCheckEnable = true,
}

ReleasePushKafakaConfigConfig = {
	KafkaTopics = "relation_push_xcpd_release",
	KafkaServers = "10.0.0.72:9092,10.0.0.73:9092,10.0.0.74:9092",
	KafkaChannelSize = 256,
	KafkaConsumerCount = 1,
	KafkaAK = "",
	KafkaPassword = "",
	KafkaCertFile = "",
	KafkaCertBytes = "",
	KafkaConsumerId = "CID_RELEASE_PUSH_FRIEND",
	TryConsumTimes = 3,
	TryConsumSleepTime = 1000,
}

ReleaseShopConfig = {
	PayValidDelayTime = 3600,
	OrderMaxValidTime = 300,
	DailySelectShopPeriod = 86400,
	LaoShouLoginDayMin = 11,
	XiaoRPayMin = 1,
	ZhongRPayMin = 30,
	DaRPayMin = 200,
	MaxPushTimes = 3,
	AgeRecordTime = 2592000,
	GiftFocusTimeLimit = 259200,
	GiftDailySendLimit = 3,
	GiftScoreLimit = 1500,
	GiftLockAgeTime = 300,
	GiftBeforeEndTime = 3600,
	CouponShopDiscount = {
		[1] = 10,
		[2] = 40,
		[234881024] = 0,
		[3] = 150,
		[4] = 400,
		[5] = 1200,
		[6] = 0,
	},
	SurpriseShopCdDayMin = 5,
	SurpriseShopCdDayMax = 9,
	SurpriseShopForbidDay = 5,
	SurpriseShopBuyDay = 3,
	SurpriseShopAdvanceCount = 2,
	SurpriseShopAdvanceAge = 4,
	DailySelectShopXiaoRDiamond = 60,
	DailySelectShopZhongRDiamond = 300,
	DailySelectShopDaRDiamond = 600,
	DirectPurchaseTopicOpenDays = 90,
	GiftRelationItemNumSingleLimit = 100,
}

SensitiveWordConfig = {
	XdTextCheckApiEnable = true,
	XdTextCheckApiTest = false,
	XdTextCheckApiUrl = "https://api-megats.xdapp.com/v1/text/check",
	XdTextCheckApiToken = "Bearer eyJhbGciOiJSUzI1NiIsImtpZCI6ImJjZGZkZTBmLTI3YTQtNDExZS05MjJhLTY0MjI4NWZmNGJmMyJ9.eyJpc3MiOiJodHRwczovL3d3dy54ZGFwcC5jb20iLCJhdWQiOiJtZWdhLnRleHRzYXZlciIsImFwcCI6InNhdXNhZ2UifQo.kz2nIU-4UZvnSTF8MSQCcuSwAbjtwgC1xmo-x6EVAJoZJSqfipQwFSqLQW_k5t3qMLJPc78tJCM6YxvtLJvXHpMvFYKLXywKWYURARMmbEWXhlTN_xGrs8OhWY-WA6xlkOm6iAdbBqzzDErYEAaKtQleXv-2aiu56vyReylGHkat2yrO7QQFFoiNGmQdgxd91-FHOlVu9MsA1NX0GA-39Tr5XoXvUkvsdPfSVWq4SILsp-JqSN35qSRtvxm6P3XWGiU07QehN85P3jOX2TJpF1_RhFsjVMeZ8fU8VIIOYQwk9Gq9fPifqT9P-B8RMyOZRlNZ3r_pORqL8TjcE7_STg",
	XdTextCheckApiApp = "sausage",
	XdTextCheckApiInterval = 86400,
	XdTextCheckApiCheckVer = 2,
	MailXdTextCheckApiEnable = true,
	ChatXdTextCheckApiEnable = true,
	ChatCheckEnable = true,
}

V2WhisperConfigConfig = {
	XdTextCheckApiEnable = true,
	XdTextCheckApiUrl = "https://whisper.cn.tapapis.com/v2/text/check",
	XClientID = "FQC99hWWVcXqo3Omej",
	XServerSecret = "erkHAiNXB1h5ZmV84Z6KYnfxWj1QzGdU",
	XSceneChat = "c2hi2cmg2oast3veeko0",
	XSceneNickname = "c2hi2clffnaipp2l1f9g",
	MailXdTextCheckApiEnable = true,
	ChatXdTextCheckApiEnable = true,
	ChatCheckEnable = true,
}

AchievementCacheConfig = {
	TimeOut = 86400,
}

ActivityMapConfig = {
	[2] = {
		ActivityId = 2,
		Name = "抽奖活动",
		StartTime = 1548604800,
		EndTime = 1557676800,
		Duration = 0,
		Notes = "",
	},
	[3] = {
		ActivityId = 3,
		Name = "抽奖活动",
		StartTime = 1548604800,
		EndTime = 1550332800,
		Duration = 0,
		Notes = "",
	},
}

ActivityTypeConfig = {
	Login = 1,
	Lottery = 2,
	Release_Lottery = 3,
}

AilevelConfig = {
	Lv1 = 1,
	Lv2 = 2,
	Lv3 = 3,
	Lv4 = 4,
	Lv5 = 5,
}

AntiAddictionConfig = {
	FCM = {
		On = 1,
		Off = 0,
	},
	FCMConfigList = {
		[0] = {
			PlayTime = 300,
			RestTime = 15,
		},
		[1] = {
			PlayTime = 180,
			RestTime = 15,
		},
	},
	FcmStatus = {
		Play = 0,
		WantRest = 1,
		Rest = 2,
	},
	RefreshTime = 18000,
	DaySecond = 86400,
	IsClose = false,
}

AntiCheatConfig = {
	IsOpenCheck = false,
	WaitTimeout = 0,
	CloseSessionWaitTime = 5,
}

AntiCheatInfoConfig = {
	version_hash = {

	},
	ip_white = {

	},
}

ChatConfig = {
	WorldChannelMaxOnline = 1000,
	WorldChannelRedisKey = "world_chat_online",
	ShutupPeriod = 1,
	ShutupErrorTime = 60,
	WorldChannelTextCD = 10,
	WorldChannelTeamCD = 30,
	LeanCloudApiUrlMap = {
		O40dyWUy2BOwaMExwXACPwh1 = "https://sausage-test.leancloud.xindong.com",
		QgmtP4ns4uiXJWUXKo0VC267 = "https://qgmtp4ns.lc-cn-n1-shared.com",
		XcLIUDN62RK5tekctUAOS3S6 = "https://sausage-release.leancloud.xindong.com",
		lOreabMOoeuuLyDnAoldVsgr = "https://sausage-first.leancloud.xindong.com",
	},
	ChatSafetyPrivateKey = "MIICXAIBAAKBgQCNK/4w006dthzTacbcgFDEngXOYnffaKiPodqq6cEMSih97zcNujBLubxg/hQCNsd6Q/D334+oy1pio8b5VteIr24cvrcuoTq+ZrpoB4COtSwwOjsVegug/wonb39kzViKEaVqNHUBAKCw6fV3Hv8MizHgN/bMBHYzeFfYRmZ6pwIDAQABAoGACajzfVrQO9l80nif+3GqVTHs+sjhI//w3Nc5880IATPH3ooybbWKXXwpqEdqjhY6gyLIB+Yb2fSETFChqmknWWBriAq7ZwwFt/OS7yq0xlUumsTry1n0SbyysBDEDFgFOzwDTKyjQ0IU00lzRES5DR/HR6xc8FGLnW51BoWYjlECQQDQTHsz8L70sUEWl2apuN4ZUrKS6VaWlijTi68Tmjd/BuD1DdGnPgoUL3L37WYkIqeAGZlPZFGy0AlMmZWC8tVxAkEArYAyAq+6kw/QLzvERt0Q8WyhrE+IRaNTos6aacKw6aT2XOz05Bo6WbpRpxqMr1GK/IPUL92XjDGu3K6mK8VllwJADLxQYBmdI0rfJul03nWuJrA2uOLJZ4Wg02Zb+v/X2s1p3bHNmsMhTKCmD+CU+SqhQSTPidohYKR1nRha2tnMEQJBAKT9TZGEbtY+qWjhWwtQWjZbaXskvqAKaxRdiDWesQHen3FK3K61yltddRyFgNePoa3z5yoFfYISFQlDBD6Hns0CQGxEUoR6BjHNgVnITfYAw6WUSyvHj+syIuqBWRvSQBJHvFoLLIb7tlQslfmm0IstBwbcMychyPrUy+o1q18Kqw8=",
	ChatSafetyPublicKey = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCNK/4w006dthzTacbcgFDEngXOYnffaKiPodqq6cEMSih97zcNujBLubxg/hQCNsd6Q/D334+oy1pio8b5VteIr24cvrcuoTq+ZrpoB4COtSwwOjsVegug/wonb39kzViKEaVqNHUBAKCw6fV3Hv8MizHgN/bMBHYzeFfYRmZ6pwIDAQAB",
	ShortSensitiveWords = {
		"QQ",
		"J8",
		"sb",
		"+q",
		"+Q",
		"+v",
		"+V",
		"TB",
		"tb",
		"Tb",
		"tB",
		"av",
		"Av",
		"aV",
		"c4",
		"C4",
		"m9",
		"M9",
		"vpn",
		"Qun",
		"cnm",
		"nmb",
		"flg",
		"7GG",
		"FM2",
		"ghb",
		"b50",
		"r32",
		"92F",
		"b58",
		"AR6",
		"pcp",
		"awp",
		"TNT",
		"f4",
		"F4",
	},
	InfoSignGenLimit = 20,
	WorldBlockTime = 604800,
	WorldBlockLimit = 200,
	WorldReportClearTime = 259200,
	LeanCloudEnable = false,
}

ChatGsConfig = {
	ChatGroupMaxOnline = 1000,
	ChatGroupRedisKey = "chat_group_online",
	ChatGroupRedisAgeKey = "chat_group_age",
	ChatGroupRedisAgeTime = 300,
	PrivateChatMaxNum = 30,
	PrivateAliveDay = 30,
	TeamChatOpen = true,
}

ClientConfig = {
	Type = {
		Android = 0,
		IOS = 1,
	},
}

ClientTypeConfig = {
	MOBILE = 0,
	EMULATOR = 1,
	HANDLE = 2,
	ContinuousCliker = 4,
}

ClubConfig = {
	RankingVersion = 1,
	NameLenLimit = 8,
	NoticeLenLimit = 100,
	ApplyJoinClubDurationLimit = 172800,
	ExitAndJoinClubCD = 7200,
	ApplyRecordNumLimit = 0,
	ApplyRecordUnixLimit = 604800,
	RecommendClubNumLimit = 30,
	ClubMemberNumLimit = 50,
	ClubCreateCostDiamond = 100,
	ClubNameChangeCostDiamond = 50,
	ClubBeInviteRecordLimit = 30,
	ClubApplyNumLimit = 100,
}

ConfigOfClientTypeCheckConfig = {
	IsCheck = false,
	NotUnet = false,
	UnetCheckTimeout = 43200,
	PunishJudgeDuration = 24,
	EmulatorHandleNum = 1000,
	MailHandleNum = 2,
	ClearHandleTime = 72,
}

CrateConfig = {
	BuyCrateNeedDonutNum = 10,
	BuyCrateNeedGoldNum = {
		700,
		1400,
		2800,
		4200,
		5600,
		7000,
	},
	BuyGoldCrateEndTime = 1560528000,
	PayCrateDailyMaxBuyCount = 99,
	PayCrateNotifyLeftDays = 14,
	ShowDateRandUseCountMax = 15,
	ShowDateRandHit1Begin = 1,
	ShowDateRandHit2Begin = 6,
	ShowDateRandHit3Begin = 11,
	ShowDateRandUseCountInterval = 5,
	ItemProbabilityUpConfs = {
		{
			QualityId = 3,
			ProbabilityMultiple = 5,
			Num = 2,
		},
		{
			QualityId = 4,
			ProbabilityMultiple = 5,
			Num = 2,
		},
	},
	PayDonutCrateDailyMaxBuyCount = 99,
	PrimeCrateDailyMaxBuyCount = 500,
	PrimeCratePromiseMaxNoPurpleCount = 9,
	BuyDiamondCandyProductMaxCount = 1000,
	BuyCrateProductMaxCount = 100,
	BuyBigCrateProductMaxCount = 500,
	DailyBuyBigCrateMaxCount = 500,
	CrateGuaranteeMaxNum = 10,
	AdCrateWatchTimeMin = 5,
	AdCrateWatchTimeMax = 30,
	RefreshAdCrateNumOffset = 21600,
	AdCrateNumRoundTime = 59,
	AdCrateEverydayGiveNum = 2,
	AdCrateFirstEnable = true,
	AdCrateReleaseEnable = true,
	AdCrateNumSuperRewardFullWeightDec = 15,
	AdCrateNumSuperRewardPartWeightDec = 5,
	AdCratePlanAwardNeedUseNum = 10,
	AdSdkTypeTT = 0,
	AdSdkTypeTapTap = 1,
	AdSdkTypeTradPlus = 2,
	AdSdkTypeWeightFirst = {
		[0] = 0,
		[1] = 0,
		[2] = 100,
	},
	AdSdkTypeWeightRelease = {
		[0] = 0,
		[1] = 0,
		[2] = 100,
	},
	DiamondRedPacketUpdateHour1 = 16,
	DiamondRedPacketUpdateHour2 = 20,
}

DataInfoConfigConfig = {
	TimeOut = 60,
}

DifficultyOfGameConfig = {
	UNDEFINED = 0,
	EASY = 1,
	HARD = 2,
}

DifficultyScoreConfig = {
	ScoreList = {
		[0] = 0,
		[1] = 0,
		[2] = 1500,
	},
}

EquipStateConfig = {
	Equip = 0,
	UnEquip = 1,
}

ErrClientMatchConfig = {
	List = {
		[0] = "成功",
		[1] = "没有空房间,不要获取房间",
		[10] = "状态错误匹配失败",
		[11] = "没有unet房间",
		[12] = "服务器关闭",
		[13] = "AI信息错误",
		[2] = "unet json api get 错误",
		[3] = "unet json api request 错误",
		[4] = "unet json marshal 错误",
		[5] = "玩家信息有问题",
		[6] = "房间信息有问题",
		[7] = "未知错误",
		[8] = "没有unet请求缓存,不能再调用这个接口",
		[9] = "匹配结束请求参数错误",
	},
}

FpsPickerConfig = {
	DeviceList = {

	},
	PidList = {
		[160399735] = 1,
		[16392] = 1,
		[182452371] = 1,
		[292528305] = 1,
		[323690511] = 1,
		[40967] = 1,
		[411345124] = 1,
		[414261852] = 1,
		[4759555] = 1,
		[4784132] = 1,
		[506495150] = 1,
		[533905490] = 1,
		[543891534] = 1,
		[712900711] = 1,
		[864772101] = 1,
		[98590838] = 1,
	},
	DeviceRatio = 0,
}

FreezeReportTypeRedisKeyConfig = {
	DeviceFreezeMode = false,
	HitBarErrorBattleDuration = 864000,
	ReportCheatingCritAbnormal = false,
	ReportCheatingMediumAbnormal = false,
	ReportCheatingHighAbnormal = false,
	ReportCheatingBattleDurationCheck = false,
	ReportBeforeFreezeShortDay = 3,
	ReportBeforeFreezeShortCount = 2,
	ReportBeforeFreezeLongDay = 30,
	ReportBeforeFreezeLongCount = 6,
	ReportBeforeFreezeTotalBattleDuration = false,
	ReportBeforeFreezePunishLevelList = {
		0,
	},
	ReportBeforeFreezeEnable = false,
	FreezeReportLimitPunishLevels = {
		7,
		8,
		10,
	},
	FreezeReportLimitExcludeSigns = {
		"MaliciousCarry",
	},
}

FriendConfig = {
	FriendRoleEnableFocusMsg = 1,
	FriendRoleEnableFansMsg = 2,
	FriendRoleDefault = 3,
	FocusMaxCount = 200,
	OnceGetFansMaxCount = 400,
	OnceGetFocusMaxCount = 400,
	BlacklistMaxCount = 200,
	SourceTypeZYQ = 1,
	SourceTypeTAPTAP = 2,
	SourceTypeALL = 3,
	TaptapFunctionOpenFirst = true,
	TaptapFunctionOpenRelease = true,
	TaptapFunctionOpenGlobal = false,
	TaptapNotifyFriendshipFirst = true,
	TaptapNotifyFriendshipRelease = true,
	TaptapNotifyFriendshipGlobal = true,
	NotifyTapPushFriendshipUrl = "https://api.xd.com/v3/sdk/pushTapFriendship",
	NotifyTapPushFriendshipKey = "c4sl9zb8gh6jaq9k",
	NotifyTaptapRoleCreatedUrl = "https://api.xd.com/v3/sdk/notify_role_created",
	NotifyTaptapRoleUpdateUrl = "https://api.xd.com/v3/sdk/notify_role_updated",
	RelationValueLimitBattleTime = 120,
	RelationValueLimitBattle = 100,
	RelationValueLimitSendGift = 30,
	RelationApplyCD = 7,
	RelationValueLimitApplyRelation = 100,
	RelationValueAddByRanking = 10,
	RelationApplyLimitCP = 1,
	RelationApplyLimitBromace = 3,
	RelationApplyLimitPartner = 3,
	RelationApplyLimitBesties = 3,
	RelationApplyLimitMax = 3,
	RelationMsgExpireDay = 30,
	FriendScoreKey = "friend:score:",
	FriendTrafficPermitLvKey = "friend:trafficPermit:",
	RelationRelationGiftAddValue = 10,
	RelationRelationGiftAddSpecialEffectsDay = 1,
	RelationRelationGiftSendWeekLimit = 50,
	RelationMsgThankRuneCountLimit = 30,
}

FriendPKConfigConfig = {
	InviteTimeout = 10,
	IsEnableFriendPKOfDevelop = true,
	IsEnableFriendPKOfRelease = true,
	IsEnableFriendPKOfGlobal = false,
}

GameServerTypeConfig = {
	DEVELOP = "develop",
	SHENHE = "shenhe",
	FIRST = "first",
	RELEASE = "release",
	MATCH = "match",
	GLOBAL = "global",
	GLOBAL_SHENHE = "global-shenhe",
}

GroupConfig = {
	GameModUnlock = {
		[4] = 2000,
	},
	GroupAuto = {
		Off = 0,
		On = 1,
	},
	NotJoin = 0,
	CanJoin = 1,
	GroupMatchAILevelStep = {
		Steps = {
			0,
			1,
			2,
			3,
			127,
		},
	},
	MatchTimeStep = 5,
	MatchLoopTimeStep = 3,
	MaxCutOffMatchTime = 30,
	DownMatchForFill = 3,
	TryGetUnetInfoTime = 10,
	ArcadeAIConfig = {
		MinScore = 0,
		MaxScore = 0,
		AILevel = 1,
		RoleNum = 14,
		QueueLen = 0,
		QueueTimeOut = 0,
		FastQueueTimeOut = 0,
		IsDown = false,
		IsAI = true,
		AIScoreList = {

		},
	},
	AIState = {
		Off = 0,
		On = 1,
	},
	GROUP_TIMEOUT = 3600,
	AutoMatchTime = 5,
	CutOffAutoMatchTime = 15,
	MinMatchTime = 3,
	IsUseGroupCache = true,
	HideScoreOfGroup = 50,
	ChatObjErr = "chat_obj_err",
	IsolationMatch = true,
	UseGunFightRoomManager = true,
}

GroupmodConfig = {
	One = 1,
	Two = 2,
	Four = 4,
}

ItemConfig = {
	BuyCrateNeedGoldNum = 100,
	ItemCustomMadeContenMaxLen = 2048,
	ItemCompensation = {
		{
			ItemId = 258,
			Count = 1,
		},
		{
			ItemId = 259,
			Count = 1,
		},
		{
			ItemId = 252,
			Count = 1,
		},
		{
			ItemId = 253,
			Count = 1,
		},
		{
			ItemId = 254,
			Count = 1,
		},
		{
			ItemId = 10,
			Count = 1,
		},
		{
			ItemId = 12,
			Count = 1,
		},
		{
			ItemId = 33,
			Count = 1,
		},
		{
			ItemId = 11,
			Count = 1,
		},
		{
			ItemId = 124,
			Count = 1,
		},
		{
			ItemId = 5,
			Count = 1,
		},
		{
			ItemId = 6,
			Count = 1,
		},
		{
			ItemId = 7,
			Count = 1,
		},
		{
			ItemId = 8,
			Count = 1,
		},
		{
			ItemId = 123,
			Count = 1,
		},
		{
			ItemId = 125,
			Count = 1,
		},
	},
	ItemCompensationEndTime = 1551369600,
	VipProductId = "com.xd.sausage.vip.12",
	ItemCustomMadePostMin = 0,
	ItemCustomMadePostMax = 5,
	DailyDiamondCandyBoxLimit = 1,
	DiamondCandyBoxOpen = 10,
	DcToDiamondRate = 1,
	DailyDiamondCandyBoxRandom = {
		1,
		2,
		3,
		5,
		7,
		10,
	},
	ChargeActivityEnable = true,
	ChargeActivity = {
		{
			ProductId = "com.xd.sausage.price.30",
			StartTime = 1564502400,
			EndTime = 1565107200,
			ExtraDiamond = 284,
		},
	},
	AdvertCrateMaxNum = 10,
	CountCrateTime = 300,
	EquipSaveMaxItemNum = 8,
	IOSActivityProductId = "com.xd.sausage.ActivityPrice.1",
	IOSActivityItemId = 898,
	IOSActivityItemNum = 3,
}

ItemStateConfig = {
	IsInit = 1,
	IsDefault = 1,
}

MailConfig = {
	ExpiredTime = 2592000,
	MaxNum = 60,
	IsMailRule = true,
}

MatchOfCoefficientConfig = {
	K = 2,
	S2k1 = 0.9,
	S3k1 = 75,
	S3k2 = 10,
	UseList = {
		{
			H = 86400,
			ScoreUsage = 0.857,
		},
		{
			H = 172800,
			ScoreUsage = 0.714,
		},
		{
			H = 259200,
			ScoreUsage = 0.571,
		},
		{
			H = 345600,
			ScoreUsage = 0.428,
		},
		{
			H = 432000,
			ScoreUsage = 0.285,
		},
		{
			H = 518400,
			ScoreUsage = 0.142,
		},
		{
			H = 604800,
			ScoreUsage = 0,
		},
	},
}

OperatingSystemConfig = {
	MAC_OS = 0,
	ANDROID = 1,
}

PlayerConfig = {
	Login = 0,
	Logout = 1,
	IsEnableAgeStatistics = false,
	RenameLevelLimit = 10,
	EnableVoiceCheck = true,
	ClientTypeSwitch = true,
	ShutupPeriod = 300,
	VoiceRefreshPeriodTime = 1800,
	ShutupThreshhold = 10,
	ShutupErrorTime = 60,
	WorldChatLevelLimit = 5,
	LoginRefreshOffsetTime = 1800,
	NickSearchCountInOnePage = 50,
	SwitchOn = 1,
	SwitchOff = 0,
	HeartBeatTimeout = 30,
	MaxNsqServerID = 100,
	SDKHeartOn = true,
	SDKHeartTimeout = 50,
	DailyReportRewardCount = false,
	SuspiciousEnable = false,
	FreezeReportEnable = false,
	OthersReportEnable = false,
	FreezePlayerEnable = false,
	FreezeReportEnableForEditor = false,
	FreezeReportEnableForIOS = false,
	FreezeReportEnableForAndroid = false,
	FreezeReportEnableForSimulator = false,
	FreezeReportPunishTypeEnable = false,
	FreezeReportAllTypeTotalCount = false,
	FreezeReportPayThreshold = 999999,
	FirstRefundFreezeThreshold = 128,
	AddActiveValuePerHour = 1,
	ActiveValueMax = 500,
	ActiveDailyFirstWarRewardDonut = 20,
	PlayerWarLikeRecordAgeTime = 86400,
	CheatingFlowMailRecord = false,
	CheatingFlowMailRecordAgain = false,
	FreezeReportPunishTypeThreshold = false,
	PunishAssistLevelThreshold = false,
	PunishAssistNumOfFreezeReport = false,
	PunishAssistPunishTypeThreshold = false,
	WarDataCheckEnable = false,
	NewPunishResponseEnable = false,
	NewPunishResponseTimeRange = false,
	NewPunishResponseLimit = false,
	AbnormalRideVehicleRecord = false,
	MaxTimestamp = 2147483000,
	ForbidRankingMode = 0,
	CloudFileList = {
		Basic = 1,
		Customize = 3,
		Gyro = 1,
		Pickup = 1,
		Sensitivity = 1,
	},
	EnablePCVersion = false,
	GameCountKey = "game:count:",
	ApproveTitleRandLimitNum = 6,
	NickMaxLen = 36,
}

PlayerIdentityConfig = {
	Soldier = 0,
	CustomRoom = 1,
	Friend = 2,
	Referee = 3,
}

PlayerRoomStateConfig = {
	OutRoom = 0,
	InRoom = 1,
}

PlayerStateConfig = {
	Offline = 0,
	Online = 1,
	Ready = 2,
	Match = 3,
	War = 4,
	Leave = 5,
	InGroup = 6,
}

RankingConfig = {
	Version = 2,
	CanReadRedis = true,
	CanWriteRedis = true,
	Keys = {

	},
	AllNotifySort = 3,
	AreaNotifySort = 1,
	MaxNotifyLen = 200,
	NotifyCacheTime = 1440,
	RankClearLogoutHour = 168,
	RankClearLastStartUnixKey = "cron_rank_clear_unix",
	RankClearSpec = "0 0 2 * * *",
	RankClearRandSec = 3600,
	RankClearEnable = true,
	MaxRankNotifyRankLimit = 100,
	MaxRankNotifyEnable = true,
	TopRankLowestLimit = 10000,
	TopRankOvertimePeriod = 604800,
	TopRankMinScore = 4000,
	TopRankScoreToStar = 100,
}

RecallActivityConfig = {
	OfflineTimeThreshold = 604800,
	RecallFriendMaxCount = 10,
}

ReportConfig = {
	ExpiredTime = 0,
	MaxDefendant = 0,
	DefendantExpiredTime = 0,
	MaxDefendantCount = 0,
}

RoomConfig = {
	MemberNumberOffset = 0,
	MemberNumberEnd = 299,
	ViewerNumberOffset = 300,
	ViewerNumberEnd = 319,
	ViewerDefaultMaxCount = 20,
	RoomAgeTime = 3600,
	ObInfoMaxLen = 2000,
	ClassicMaxCount = 100,
	ArcadeMaxCount = 28,
	TeamMaxCount = 16,
	JujiMaxCount = 16,
	HideMaxCount = 12,
	RainbowFightMaxCount = 12,
	WarConfMaxLen = 4000,
	RoomLockTime = 10,
	StartGameDelayTime = 3,
	RoomCardTimeout = 7200,
	CloseTheRoomCardTimeout = false,
	RoomCardEnableFirst = true,
	RoomCardEnableRelease = true,
	CreateRoomCoolingTime = 600,
}

ServerTypeConfig = {
	Account = 1,
	Group = 2,
	RoomMaster = 3,
	ChatGsGroup = 4,
	ClubGroup = 5,
	Protos = {
		Proto_Achievement = 1,
		Proto_Announcement = 1,
		Proto_Friend = 1,
		Proto_Item = 1,
		Proto_Mail = 1,
		Proto_Match = 1,
		Proto_Player = 1,
		Proto_Team = 0,
		Proto_War = 1,
		Proto_Wardrobe = 1,
		Proto_Group = 2,
		Proto_GroupAccount = 1,
		Proto_Ranking = 1,
		Proto_Task = 1,
		Proto_Activity = 1,
		Proto_RedPoint = 1,
		Proto_Crate = 1,
		Proto_VIP = 1,
		Proto_Chat = 1,
		Proto_WarFlag = 1,
		Proto_TrafficPermit = 1,
		Proto_SeasonInfo = 1,
		Proto_Observer = 1,
		Proto_Room = 1,
		Proto_RoomMaster = 3,
		Proto_Shop = 1,
		Proto_GameFunction = 1,
		Proto_DataInfo = 1,
		Proto_MatchClient = 1,
		Proto_Zone = 1,
		Proto_Title = 1,
		Proto_SensitiveWord = 1,
		Proto_ChatGsGroup = 4,
		Proto_ChatGs = 1,
		Proto_ChatOts = 1,
		Proto_ClubGroup = 5,
		Proto_ClubAccount = 1,
	},
}

TaskConfig = {
	RefreshOffsetTime = 0,
	RefreshTaskMaxCount = 1,
	AddTaskCollectItemLimit = 100,
	UltramanActivityTaskAdd = 0.5,
}

TrafficPermitConfig = {
	MedalCountPerLevel = 100,
	MaxLevel = 275,
	BuyMaxLevel = 100,
	WarSeasonSleepTime = 3600,
	SendMedalWhenAddOneLevel = 1,
	TaskLevelMin = 1,
	AwardDonutLevelMax = 100,
	TrafficPermitActivityMap = {
		[1] = {
			ActivityId = 1,
			Name = "先行通行证活动",
			StartTime = 1611763200,
			EndTime = 1614527999,
		},
		[2] = {
			ActivityId = 2,
			Name = "正式通行证活动",
			StartTime = 1611763200,
			EndTime = 1614527999,
		},
	},
	DailyMaxBattleTime = 7200,
	DiamondToTaskCard = 10,
	ActivityRewardReissue = true,
	IosRecommendBackTime = 604800,
	IosReissueRewardTime = 1209600,
	BackActivityBackTime = 604800,
	BackActivityScoreProtectTime = 604800,
	BackActivityScoreProtectDailyMaxNum = 1,
	CycleActivityRewardDelayTime = 259200,
	LimitActivityRewardDelayTime = 259200,
	DailyTaskPuTongRefreshNum = 1,
	DailyTaskXiYouRefreshNum = 2,
	DailyTaskShiShiRefreshNum = 2,
	SeasonBigRevealOldPlayerInit = 31,
	MengXinActivityDuration = 14,
}

UnetConfig = {
	HTTPTimeout = 5,
	WorldTimeout = 600,
	DebugOpen = 7,
	FreezeKillListOpen = 1,
}

VipConfig = {
	DailyRewardItemNum = 10,
}

WarConfig = {
	DoTagMatchTest = false,
	StartRecordTimeOut = 3600,
	WarEventTimeOut = 2,
	DayCountRushTime = 0,
	DailyWarExpLimit = 30000,
	MaxWatchCount = 20,
	NotifyTimeout30s = 30,
	NotifyTimeout60s = 60,
	NotifyTimeout5m = 300,
	NotifyCacheTimeout = 86400,
	MaxWarResultCount = 3,
	IsNewMatchServer = true,
}

WarStateConfig = {
	LOGIN = 0,
	RANGE = 1,
	WAR_INIT = 2,
	PLAY = 3,
	WATCH = 4,
}

table.setReadAndWriteVerify(DevelopPushKafakaConfigConfig)
table.setReadAndWriteVerify(FirstPushKafakaConfigConfig)
table.setReadAndWriteVerify(FirstSensitiveWordConfig)
table.setReadAndWriteVerify(FirstV2WhisperConfigConfig)
table.setReadAndWriteVerify(GlobalShopConfig)
table.setReadAndWriteVerify(GlobalV2WhisperConfigConfig)
table.setReadAndWriteVerify(ReleasePushKafakaConfigConfig)
table.setReadAndWriteVerify(ReleaseShopConfig)
table.setReadAndWriteVerify(SensitiveWordConfig)
table.setReadAndWriteVerify(V2WhisperConfigConfig)
table.setReadAndWriteVerify(AchievementCacheConfig)
table.setReadAndWriteVerify(ActivityMapConfig)
table.setReadAndWriteVerify(ActivityTypeConfig)
table.setReadAndWriteVerify(AilevelConfig)
table.setReadAndWriteVerify(AntiAddictionConfig)
table.setReadAndWriteVerify(AntiCheatConfig)
table.setReadAndWriteVerify(AntiCheatInfoConfig)
table.setReadAndWriteVerify(ChatConfig)
table.setReadAndWriteVerify(ChatGsConfig)
table.setReadAndWriteVerify(ClientConfig)
table.setReadAndWriteVerify(ClientTypeConfig)
table.setReadAndWriteVerify(ClubConfig)
table.setReadAndWriteVerify(ConfigOfClientTypeCheckConfig)
table.setReadAndWriteVerify(CrateConfig)
table.setReadAndWriteVerify(DataInfoConfigConfig)
table.setReadAndWriteVerify(DifficultyOfGameConfig)
table.setReadAndWriteVerify(DifficultyScoreConfig)
table.setReadAndWriteVerify(EquipStateConfig)
table.setReadAndWriteVerify(ErrClientMatchConfig)
table.setReadAndWriteVerify(FpsPickerConfig)
table.setReadAndWriteVerify(FreezeReportTypeRedisKeyConfig)
table.setReadAndWriteVerify(FriendConfig)
table.setReadAndWriteVerify(FriendPKConfigConfig)
table.setReadAndWriteVerify(GameServerTypeConfig)
table.setReadAndWriteVerify(GroupConfig)
table.setReadAndWriteVerify(GroupmodConfig)
table.setReadAndWriteVerify(ItemConfig)
table.setReadAndWriteVerify(ItemStateConfig)
table.setReadAndWriteVerify(MailConfig)
table.setReadAndWriteVerify(MatchOfCoefficientConfig)
table.setReadAndWriteVerify(OperatingSystemConfig)
table.setReadAndWriteVerify(PlayerConfig)
table.setReadAndWriteVerify(PlayerIdentityConfig)
table.setReadAndWriteVerify(PlayerRoomStateConfig)
table.setReadAndWriteVerify(PlayerStateConfig)
table.setReadAndWriteVerify(RankingConfig)
table.setReadAndWriteVerify(RecallActivityConfig)
table.setReadAndWriteVerify(ReportConfig)
table.setReadAndWriteVerify(RoomConfig)
table.setReadAndWriteVerify(ServerTypeConfig)
table.setReadAndWriteVerify(TaskConfig)
table.setReadAndWriteVerify(TrafficPermitConfig)
table.setReadAndWriteVerify(UnetConfig)
table.setReadAndWriteVerify(VipConfig)
table.setReadAndWriteVerify(WarConfig)
table.setReadAndWriteVerify(WarStateConfig)