local FreezeReportTypePunishTable = class({}, Assets.req("Scripts.ConfigTable.Base.FreezeReportTypePunishTableBase"))
-- 通过 Id 得到内容

--------------------------------------------自动生成--------------------------------------------

return FreezeReportTypePunishTable
