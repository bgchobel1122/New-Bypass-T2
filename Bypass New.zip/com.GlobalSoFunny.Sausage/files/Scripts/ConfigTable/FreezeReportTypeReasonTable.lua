local FreezeReportTypeReasonTable = class({}, Assets.req("Scripts.ConfigTable.Base.FreezeReportTypeReasonTableBase"))
-- 通过 Id 得到内容

return FreezeReportTypeReasonTable
