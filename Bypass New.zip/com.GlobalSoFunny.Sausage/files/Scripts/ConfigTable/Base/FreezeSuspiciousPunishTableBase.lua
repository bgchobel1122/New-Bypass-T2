local List0 = {
	
}

local Keys = {603979776,603979777,603979778,}

return FreezeSuspiciousPunishTableBase