local List0 = {
	
}

local Keys = {838860800,872415232,}






return FreezeReportTypeExtraTableBase