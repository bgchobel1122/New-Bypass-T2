local List0 = {
	[1] = {1,1,12},
	[2] = {2,2,24},
	[3] = {3,3,48},
	[4] = {4,4,96},
	[5] = {5,5,168},
}

local Keys = {1,2,3,4,5,}







return EmulatorPunishLevelTableBase