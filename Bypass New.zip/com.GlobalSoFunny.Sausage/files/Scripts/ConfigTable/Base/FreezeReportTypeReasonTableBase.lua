local List0 = {
	
}

local Keys = {1,2,335544320,838860800,838860801,872415232,1275068416,1275068417,1275068418,1275068419,1275068420,}



local languageColumns = {3, 5}
local mt = {
    __index = function(self, key)
        if not key then
            return nil
        end
        return CS.Language.GetConfigContent(self[1000 + key])
    end,
    __metatable = "Don't edit metatable."
}
for k, v in pairs(List0) do
    v.__index = v
    for index, column in pairs(languageColumns) do
        v[1000 + column] = v[column]
        v[column] = nil
    end
    v.__metatable = "Don't edit metatable."
    setmetatable(v, mt)
end

return FreezeReportTypeReasonTableBase