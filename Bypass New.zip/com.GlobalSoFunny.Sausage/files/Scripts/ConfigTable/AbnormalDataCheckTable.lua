local AbnormalDataCheckTable = class({}, Assets.req("Scripts.ConfigTable.Base.AbnormalDataCheckTableBase"))
-- 通过 Id 得到内容
--------------------------------------------自动生成--------------------------------------------

return AbnormalDataCheckTable